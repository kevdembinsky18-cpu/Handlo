import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, Search, User, Plus, X, Menu, Tag, Truck, CreditCard, Filter, Heart, Trash2, Upload, Package, Settings } from "lucide-react";

/* Theme colors */
const theme = {
  brand: {
    name: "Handlo",
    primary: "#FFD54F",
    primarySoft: "#FFE082",
    accent: "#FF8A00",
    accentSoft: "#FFB74D",
    dark: "#1F2937",
  },
};

/* Mock data (short) */
const mockProducts = [
  {
    id: "p1",
    title: "Słuchawki bezprzewodowe X200",
    price: 249.99,
    rating: 4.6,
    reviews: 132,
    category: "electronics",
    seller: "AudioPro",
    image: "https://images.unsplash.com/photo-1518449073235-22463b2bba20?q=80&w=1200&auto=format&fit=crop",
    tags: ["Nowe", "Dostawa 24h"],
  },
  {
    id: "p2",
    title: "Ekspres do kawy Barista Mini",
    price: 499.0,
    rating: 4.8,
    reviews: 89,
    category: "home",
    seller: "CaffePoint",
    image: "https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop",
    tags: ["Bestseller"],
  },
  {
    id: "p3",
    title: "Kurtka wiatrówka AeroLight",
    price: 189.99,
    rating: 4.4,
    reviews: 57,
    category: "fashion",
    seller: "UrbanWear",
    image: "https://images.unsplash.com/photo-1539533113208-f6df8cc8b543?q=80&w=1200&auto=format&fit=crop",
    tags: ["Wyprzedaż"],
  },
];

const formatPrice = (n) => new Intl.NumberFormat("pl-PL", { style: "currency", currency: "PLN" }).format(n);

function AppShell({ children, onOpenCart, cartCount, onToggleMenu, isMenuOpen, onGo }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-white to-orange-100" style={{ backgroundImage: `radial-gradient(20% 20% at 10% 0%, ${theme.brand.primarySoft}22, transparent 70%), radial-gradient(20% 20% at 90% 0%, ${theme.brand.accentSoft}22, transparent 70%)` }}>
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-yellow-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-3">
          <button className="md:hidden p-2 rounded-xl hover:bg-yellow-100" onClick={onToggleMenu} aria-label="Otwórz menu">
            {isMenuOpen ? <X /> : <Menu />}
          </button>
          <div onClick={() => onGo("home")} className="flex items-center gap-2 cursor-pointer">
            <div className="w-9 h-9 rounded-2xl flex items-center justify-center shadow-inner" style={{ background: theme.brand.primary }}>
              <Tag className="w-5 h-5" />
            </div>
            <div className="leading-tight">
              <div className="text-xl font-extrabold" style={{ color: theme.brand.dark }}>Handlo</div>
              <div className="text-[11px] uppercase tracking-widest" style={{ color: theme.brand.accent }}>Marketplace</div>
            </div>
          </div>
          <div className="flex-1" />
          <div className="hidden md:flex items-center gap-2 flex-1 max-w-2xl">
            <div className="flex items-center w-full bg-white rounded-2xl shadow-inner border border-yellow-200 focus-within:ring-2 focus-within:ring-orange-400">
              <Search className="w-5 h-5 ml-3 opacity-60" />
              <input placeholder="Szukaj produktów, kategorii, sprzedawców…" className="w-full bg-transparent px-3 py-2 outline-none text-sm" />
              <button className="m-1 px-3 py-1.5 rounded-xl text-sm font-medium" style={{ background: theme.brand.accent, color: "white" }}>Szukaj</button>
            </div>
          </div>
          <div className="flex items-center gap-2 ml-2">
            <button onClick={onOpenCart} data-cy="cart-button" className="relative px-3 py-2 rounded-xl hover:bg-yellow-100">
              <ShoppingCart />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 text-[10px] leading-none bg-orange-500 text-white px-1.5 py-1 rounded-full shadow">{cartCount}</span>
              )}
            </button>
            <button className="px-3 py-2 rounded-xl hover:bg-yellow-100"><User /></button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex">
        <main className="flex-1 md:pl-6">
          {children}
        </main>
      </div>

      <footer className="mt-6 border-t border-yellow-200 bg-white/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 text-sm flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-12">
          <div className="flex-1">
            <div className="text-lg font-extrabold">{theme.brand.name}</div>
            <p className="text-gray-600 max-w-md">Nowoczesny marketplace łączący sprzedawców i kupujących. Szybko, bezpiecznie i wygodnie.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 w-full md:w-auto">
            <div>
              <div className="font-semibold mb-2">Handlo</div>
              <ul className="space-y-1 text-gray-600">
                <li>O nas</li>
                <li>Kariera</li>
                <li>Blog</li>
              </ul>
            </div>
            <div>
              <div className="font-semibold mb-2">Wsparcie</div>
              <ul className="space-y-1 text-gray-600">
                <li>Centrum pomocy</li>
                <li>Zwroty</li>
                <li>Regulamin</li>
              </ul>
            </div>
            <div>
              <div className="font-semibold mb-2">Sprzedaż</div>
              <ul className="space-y-1 text-gray-600">
                <li>Panel sprzedawcy</li>
                <li>Opłaty</li>
                <li>API</li>
              </ul>
            </div>
            <div>
              <div className="font-semibold mb-2">Pobierz</div>
              <ul className="space-y-1 text-gray-600">
                <li>iOS</li>
                <li>Android</li>
                <li>Web</li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function HomePage({ onViewProduct, onGo }) {
  return (
    <>
      <section className="relative overflow-hidden rounded-3xl border border-yellow-200 bg-white/80 shadow-sm p-6 md:p-10 flex flex-col md:flex-row items-center gap-8">
        <div className="flex-1">
          <h1 className="text-3xl md:text-5xl font-extrabold leading-tight" style={{ color: theme.brand.dark }}>
            Wszystko, czego potrzebujesz —
            <span className="block" style={{ color: theme.brand.accent }}>w jednym Handlo.</span>
          </h1>
          <p className="mt-3 text-gray-700 max-w-xl">Przeglądaj oferty od zweryfikowanych sprzedawców. Bezpieczne płatności, szybka dostawa i przejrzyste zasady.</p>
          <div className="mt-4 flex flex-wrap gap-3">
            <button onClick={() => onGo("dashboard")} className="px-4 py-2 rounded-2xl font-semibold shadow" style={{ background: theme.brand.accent, color: "white" }}>
              <span className="inline-flex items-center gap-2"><Plus className="w-4 h-4" /> Dodaj ofertę</span>
            </button>
            <button onClick={() => onGo("catalog")} className="px-4 py-2 rounded-2xl font-semibold bg-white border border-yellow-200">
              Przeglądaj oferty
            </button>
          </div>
        </div>

        <div className="flex-1 w-full">
          <div className="grid grid-cols-2 gap-3">
            {mockProducts.slice(0, 4).map((p) => (
              <motion.div key={p.id} whileHover={{ y: -4 }} className="rounded-2xl overflow-hidden border border-yellow-200 bg-white/80 shadow-sm cursor-pointer" onClick={() => onViewProduct && onViewProduct(p)}>
                <div className="aspect-[4/3] bg-gray-100" style={{ backgroundImage: `url(${p.image})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
                <div className="p-3">
                  <div className="text-sm font-semibold line-clamp-1">{p.title}</div>
                  <div className="text-sm text-gray-600">{formatPrice(p.price)}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="mt-6">
        <div className="flex items-center gap-2 overflow-auto pb-2">
          <button className="px-4 py-2 rounded-full border border-yellow-200 bg-white/80 shadow-sm hover:shadow">Wszystko</button>
          <button className="px-4 py-2 rounded-full" style={{ background: theme.brand.primary }}>Pokaż wszystko</button>
        </div>
      </section>

      <section className="mt-6 grid md:grid-cols-3 gap-4">
        {mockProducts.map((p) => (
          <ProductCard key={p.id} product={p} onClick={() => onViewProduct && onViewProduct(p)} />
        ))}
      </section>
    </>
  );
}

function ProductCard({ product, onClick }) {
  return (
    <motion.div data-cy="product-card" whileHover={{ y: -4 }} className="rounded-3xl overflow-hidden border border-yellow-200 bg-white/80 shadow-sm cursor-pointer" onClick={onClick}>
      <div className="aspect-[4/3] bg-gray-100" style={{ backgroundImage: `url(${product.image})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="font-semibold line-clamp-2 leading-snug">{product.title}</h3>
            <div className="mt-1 text-sm text-gray-600">Sprzedawca: {product.seller}</div>
          </div>
          <button className="p-2 rounded-xl hover:bg-yellow-100" aria-label="Dodaj do ulubionych"><Heart /></button>
        </div>
        <div className="mt-2 flex items-center justify-between">
          <div className="text-lg font-extrabold" style={{ color: theme.brand.accent }}>{formatPrice(product.price)}</div>
        </div>
        <div className="mt-3">
          <button className="w-full px-4 py-2 rounded-2xl font-semibold shadow" style={{ background: theme.brand.primary }}>
            Dodaj do koszyka
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export default function HandloApp() {
export default function HandloApp() {
  const [route, setRoute] = useState("home");
  const [current, setCurrent] = useState(null);
  const [cart, setCart] = useState(() => {
    try {
      const raw = localStorage.getItem("handlo_cart_v1");
      return raw ? JSON.parse(raw) : [];
    } catch (e) { return []; }
  });
  const [drawer, setDrawer] = useState(false);
  const [menu, setMenu] = useState(false);
  const [catalog, setCatalog] = useState(mockProducts);
  const [user, setUser] = useState(() => {
    try {
      const raw = localStorage.getItem("handlo_user_v1");
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  });

  // persist cart
  useEffect(() => {
    try { localStorage.setItem("handlo_cart_v1", JSON.stringify(cart)); } catch(e){}
  }, [cart]);

  // persist user
  useEffect(() => {
    try { localStorage.setItem("handlo_user_v1", JSON.stringify(user)); } catch(e){}
  }, [user]);

  const go = (r) => { setRoute(r); setMenu(false); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  const openProduct = (p) => { setCurrent(p); setRoute("product"); };

  const addToCart = (p) => {
    setCart((c) => {
      const idx = c.findIndex((i) => i.id === p.id);
      if (idx === -1) return [...c, { ...p, qty: 1 }];
      const copy = [...c];
      copy[idx] = { ...copy[idx], qty: copy[idx].qty + 1 };
      return copy;
    });
    setDrawer(true);
  };

  const removeFromCart = (id) => setCart((c) => c.filter((i) => i.id !== id));

  const addNewProduct = (p) => {
    setCatalog((prev) => [p, ...prev]);
    setRoute("catalog");
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("handlo_user_v1");
    go("home");
  };

  const loginMock = ({email, name}) => {
    const u = { id: 'u_' + (Math.random().toString(36).slice(2)), email, name };
    setUser(u);
    return u;
  };

  return (
    <AppShell
      onOpenCart={() => setDrawer(true)}
      cartCount={cart.reduce((s, i) => s + i.qty, 0)}
      onToggleMenu={() => setMenu((m) => !m)}
      isMenuOpen={menu}
      onGo={go}
    >
      {/* simple top-right user area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex justify-end items-center gap-2 text-sm mt-3">
          {user ? (
            <>
              <div className="px-3 py-1 rounded-full bg-white border border-yellow-200">{user.name || user.email}</div>
              <button onClick={logout} className="px-3 py-1 rounded-xl hover:bg-yellow-100">Wyloguj</button>
            </>
          ) : (
            <>
              <button onClick={()=>go('login')} className="px-3 py-1 rounded-xl hover:bg-yellow-100">Zaloguj</button>
              <button onClick={()=>go('register')} className="px-3 py-1 rounded-xl hover:bg-yellow-100">Rejestracja</button>
            </>
          )}
        </div>
      </div>

      {route === "home" && <HomePage onViewProduct={openProduct} onGo={go} />}
      {route === "catalog" && <div><h2 className="text-xl font-bold mb-4">Wszystkie oferty</h2><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{catalog.map(p=> <ProductCard key={p.id} product={p} onClick={()=>openProduct(p)}/>)}</div></div>}
      {route === "product" && <div className="space-y-4"><h2 className="text-2xl font-bold">{current?.title}</h2><p>{current?.seller} • {formatPrice(current?.price)}</p><div className="flex gap-3"><button onClick={()=>addToCart(current)} className="px-4 py-2 rounded-2xl" style={{background:theme.brand.accent,color:'white'}}>Dodaj do koszyka</button></div></div>}
      {route === "dashboard" && (user ? <div className="space-y-6"><div className="rounded-3xl border border-yellow-200 bg-white/80 shadow-sm p-4 flex items-center justify-between"><div><div className="text-lg font-bold">Panel sprzedawcy</div><div className="text-gray-700">Zarządzaj ofertami, zamówieniami i ustawieniami sklepu.</div></div><button onClick={()=>go('add')} className="px-4 py-2 rounded-2xl font-semibold shadow text-white" style={{background: theme.brand.accent}}>Dodaj ofertę</button></div></div> : <div className="rounded-3xl border border-yellow-200 bg-white/80 p-4">Aby zarządzać sprzedażą, zaloguj się.</div>)}
      {route === "add" && (user ? <div className="rounded-3xl border border-yellow-200 bg-white/80 p-4">Formularz dodawania produktu (demo)</div> : <div className="rounded-3xl border border-yellow-200 bg-white/80 p-4">Zaloguj się, aby dodać ofertę.</div>)}

      {route === "login" && <AuthLogin onLogin={(u)=>{ loginMock(u); go('dashboard'); }} onBack={()=>go('home')} />}
      {route === "register" && <AuthRegister onRegister={(u)=>{ loginMock(u); go('dashboard'); }} onBack={()=>go('home')} />}

      <AnimatePresence>{drawer && <div className="fixed inset-0 z-40"><div className="absolute inset-0 bg-black/30" onClick={()=>setDrawer(false)}></div><div className="absolute right-0 top-0 bottom-0 w-full sm:w-[420px] bg-white p-4"><CartDrawerDemo items={cart} onRemove={removeFromCart} /></div></div>}</AnimatePresence>
    </AppShell>
  );
}

function AuthLogin({ onLogin, onBack }) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  return (
    <div className="max-w-md mx-auto rounded-3xl border border-yellow-200 bg-white/80 p-6">
      <h2 className="text-xl font-bold mb-2">Zaloguj się / Szybkie demo</h2>
      <p className="text-sm text-gray-600 mb-4">W demo wystarczy podać imię i email.</p>
      <label className="block text-sm">Imię<input value={name} onChange={e=>setName(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-xl border border-yellow-200 bg-white" /></label>
      <label className="block text-sm mt-2">Email<input value={email} onChange={e=>setEmail(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-xl border border-yellow-200 bg-white" /></label>
      <div className="mt-4 flex gap-2">
        <button onClick={()=>onLogin({email, name})} className="px-4 py-2 rounded-2xl" style={{background:theme.brand.accent,color:'white'}}>Zaloguj</button>
        <button onClick={onBack} className="px-4 py-2 rounded-2xl border border-yellow-200">Wróć</button>
      </div>
    </div>
  );
}

function AuthRegister({ onRegister, onBack }) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  return (
    <div className="max-w-md mx-auto rounded-3xl border border-yellow-200 bg-white/80 p-6">
      <h2 className="text-xl font-bold mb-2">Rejestracja (demo)</h2>
      <p className="text-sm text-gray-600 mb-4">W demo utworzymy konto lokalnie (localStorage).</p>
      <label className="block text-sm">Imię<input value={name} onChange={e=>setName(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-xl border border-yellow-200 bg-white" /></label>
      <label className="block text-sm mt-2">Email<input value={email} onChange={e=>setEmail(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-xl border border-yellow-200 bg-white" /></label>
      <div className="mt-4 flex gap-2">
        <button onClick={()=>onRegister({email, name})} className="px-4 py-2 rounded-2xl" style={{background:theme.brand.accent,color:'white'}}>Zarejestruj</button>
        <button onClick={onBack} className="px-4 py-2 rounded-2xl border border-yellow-200">Wróć</button>
      </div>
    </div>
  );
}

function CartDrawerDemo({ items, onRemove }) {
  const total = (items||[]).reduce((s,i)=>s + i.price * i.qty, 0);
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-3"><div className="font-bold text-lg">Twój koszyk</div></div>
      <div className="flex-1 overflow-auto space-y-3">
        {items.length===0 && <div className="text-gray-600">Koszyk jest pusty</div>}
        {items.map(i=>(
          <div key={i.id} className="flex gap-3 p-3 rounded-2xl border border-yellow-200 bg-white/80">
            <div className="w-20 h-16 rounded-xl bg-gray-100" style={{backgroundImage:`url(${i.image})`, backgroundSize:'cover', backgroundPosition:'center'}} />
            <div className="flex-1">
              <div className="text-sm font-semibold">{i.title}</div>
              <div className="text-xs text-gray-600">Ilość: {i.qty}</div>
              <div className="text-sm font-bold" style={{color:theme.brand.accent}}>{formatPrice(i.price * i.qty)}</div>
            </div>
            <button onClick={()=>onRemove(i.id)} className="p-2 rounded-xl hover:bg-yellow-100"><Trash2 /></button>
          </div>
        ))}
      </div>
      <div className="p-4 border-t border-yellow-200">
        <div className="flex items-center justify-between mb-3"><span className="text-sm text-gray-700">Razem</span><span className="text-lg font-extrabold" style={{color:theme.brand.accent}}>{formatPrice(total)}</span></div>
        <button className="w-full px-4 py-3 rounded-2xl font-semibold shadow text-white" style={{background:theme.brand.accent}}>Przejdź do płatności</button>
      </div>
    </div>
  );
}
