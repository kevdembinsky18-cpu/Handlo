# Handlo — Prototype (Vite + React + Tailwind)

This is a frontend prototype for the **Handlo** marketplace (colors: yellow + orange).
Included:
- React + Vite setup
- Tailwind CSS
- Framer Motion and Lucide icons
- Mock catalog, product cards, cart drawer, seller dashboard (UI only)

## How to run

1. Install dependencies:
   ```
   npm install
   ```
2. Start dev server:
   ```
   npm run dev
   ```
3. Open in browser (Vite will show the URL, typically http://localhost:5173)

## Next steps / suggestions
- Add authentication (e.g. NextAuth or custom)
- Integrate backend (products, users, orders)
- Persist cart to localStorage
- Add Stripe / Payment provider
- Polish i18n (react-intl or i18next)



## Backend (mock) — Express

A minimal Express mock server is included in the `server/` folder. It provides:
- `GET /api/products` — list of mock products
- `POST /api/register` — register a mock user (stores in memory)
- `POST /api/login` — login a mock user
- `POST /api/create-checkout-session` — Stripe checkout session scaffold (requires `STRIPE_SECRET_KEY` env var on server)

### Run server
From project root:
```bash
# install server deps
cd server
npm install
# start server
npm run start
# or in dev with nodemon
npm run dev
```

The server starts on port `4000` by default.

## Features added in this update

- **Authentication (demo)**: simple Login / Register pages that store user in `localStorage` (demo-only).
- **Cart persistence**: cart is saved to `localStorage` (`handlo_cart_v1`).
- **Mock backend**: Express server with product/auth endpoints and a Stripe scaffold.
- **Stripe scaffold**: server route to create Checkout Sessions. To use it in production, set `STRIPE_SECRET_KEY` env var on the server and implement secure server-side logic.
- **Deployment tips**:
  - Frontend: deploy `handlo-prototype` to Vercel or Netlify (build command `npm run build`).
  - Backend: deploy `server` to Heroku / Railway / Render / Fly with `STRIPE_SECRET_KEY` set in env.
  - For full production, replace mock auth with a real user database and secure sessions/JWT.

## Quick local run (full stack)
1. Install frontend deps:
   ```
   npm install
   ```
2. Install server deps:
   ```
   cd server
   npm install
   ```
3. Start server:
   ```
   npm run start
   ```
4. In another terminal start frontend:
   ```
   npm run dev
   ```
Frontend (Vite) will usually run on `http://localhost:5173` and server on `http://localhost:4000`.

## Security & env
 - Set `JWT_SECRET` (recommended) to a strong secret for production to sign tokens.
 - Set `STRIPE_SECRET_KEY` to enable Stripe checkout creation on the server.

## Docker
A simple Dockerfile is included for running the server. Build with:
```
Docker build -t handlo-server .
Docker run -e STRIPE_SECRET_KEY=sk_test_xxx -p 4000:4000 handlo-server
```

## Prisma + Postgres scaffold
A `prisma/schema.prisma` is included as a scaffold if you want to migrate from SQLite to Postgres.
To use Prisma:
```
cd server
npm install prisma --save-dev @prisma/client
npx prisma migrate dev --name init
```

## Webhook fulfillment & email notifications
The server now creates an `orders` record in SQLite when Stripe sends `checkout.session.completed` webhook.
To enable email confirmations, set the following env vars on your server:
- `SENDGRID_API_KEY` — your SendGrid API key
- `SENDER_EMAIL` — verified sender email address

Webhook setup tip: use `stripe listen --forward-to localhost:4000/api/webhook` during local development.

## CI: running E2E
The CI config includes a job to run Cypress tests. It expects the server and frontend to be started before tests run. You may need to adjust the `services` configuration or use `start-server-and-test` in the workflow.

## Docker Compose (local full-stack)
Use the included `docker-compose.yml` to run Postgres + server + frontend locally.
1. Copy `.env.example` to `.env` and adjust any secrets.
2. Run:
```
docker-compose up --build
```
Frontend: http://localhost:5173, Server: http://localhost:4000

## Prisma migrations (migrate to Postgres)
The project includes `prisma/schema.prisma`. To use Postgres with Prisma:
```
# from project root
cd server
npm install prisma --save-dev @prisma/client
# set DATABASE_URL in .env (or use docker-compose env)
npx prisma migrate dev --name init --schema=../prisma/schema.prisma
# generate client
npm run prisma:generate
# (optional) open studio
npm run prisma:studio
```
After running migrations, you can seed the DB using `node server/seed.js` (implement seed logic as needed).
