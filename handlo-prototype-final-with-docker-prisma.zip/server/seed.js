
/**
 * Simple seed script to populate Postgres DB via DATABASE_URL using node-postgres or prisma client.
 * This file is a scaffold — run after migrations.
 */

console.log('Seed scaffold: implement using Prisma or node-postgres. Example with Prisma:');
console.log('1) Install dev deps: npm install prisma --save-dev @prisma/client');
console.log('2) Run migrations: npx prisma migrate dev --name init');
console.log('3) Run seed: node server/seed.js');
