
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const Stripe = require('stripe');
const sgMail = require('@sendgrid/mail');

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const DB_FILE = path.join(__dirname, 'handlo.db');
const SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const STRIPE_KEY = process.env.STRIPE_SECRET_KEY || null;
const SENDGRID_KEY = process.env.SENDGRID_API_KEY || null;
const SENDER_EMAIL = process.env.SENDER_EMAIL || null;
if (SENDGRID_KEY) { sgMail.setApiKey(SENDGRID_KEY); }

const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database(DB_FILE);

// init tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE,
    name TEXT,
    password TEXT,
    role TEXT DEFAULT 'user'
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    title TEXT,
    price REAL,
    image TEXT,
    seller TEXT
  )`);
  // seed products if empty
  db.get('SELECT COUNT(*) as c FROM products', (err, row) => {
    if (!err && row && row.c === 0) {
      const stmt = db.prepare('INSERT INTO products (id,title,price,image,seller) VALUES (?,?,?,?,?)');
      stmt.run('p1','Słuchawki X200',249.99,'https://images.unsplash.com/photo-1518449073235-22463b2bba20?q=80&w=1200&auto=format&fit=crop','AudioPro');
      stmt.run('p2','Ekspres Barista',499.0,'https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop','CaffePoint');
      stmt.finalize();
    }
  });
});


// Orders table
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    session_id TEXT,
    customer_email TEXT,
    amount REAL,
    currency TEXT,
    items TEXT,
    paid INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

const app = express();
app.use(cors());
app.use(bodyParser.json());

// helper
function createToken(user) {
  const payload = { id: user.id, email: user.email, name: user.name, role: user.role || 'user' };
  return jwt.sign(payload, SECRET, { expiresIn: '7d' });
}

// Routes
app.get('/api/products', (req, res) => {
  db.all('SELECT * FROM products ORDER BY rowid DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/register', async (req, res) => {
  const { email, name, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email + password required' });
  const hashed = await bcrypt.hash(password, 10);
  const id = 'u_' + Math.random().toString(36).slice(2);
  db.run('INSERT INTO users (id,email,name,password) VALUES (?,?,?,?)', [id, email, name || '', hashed], function(err) {
    if (err) return res.status(400).json({ error: err.message });
    const user = { id, email, name: name || '' };
    const token = createToken(user);
    res.json({ user, token });
  });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email + password required' });
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(404).json({ error: 'User not found' });
    const ok = await bcrypt.compare(password, row.password);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    const user = { id: row.id, email: row.email, name: row.name, role: row.role };
    const token = createToken(user);
    res.json({ user, token });
  });
});

// Middleware to protect routes
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'Missing token' });
  const parts = auth.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'Invalid auth header' });
  const token = parts[1];
  try {
    const payload = jwt.verify(token, SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Admin: create product
app.post('/api/products', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin' && req.user.role !== 'user') {
    // allow user to create product but tag seller as user
  }
  const { title, price, image } = req.body;
  const id = 'p_' + Math.random().toString(36).slice(2);
  db.run('INSERT INTO products (id,title,price,image,seller) VALUES (?,?,?,?,?)', [id, title, price, image, req.user.email || req.user.name || 'seller'], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id, title, price, image });
  });
});

// Stripe checkout session
app.post('/api/create-checkout-session', async (req, res) => {
  if (!STRIPE_KEY) return res.status(500).json({ error: 'Stripe key not configured on server.' });
  const stripe = Stripe(STRIPE_KEY);
  const items = req.body.items || [];
  // items expected { price_data: {currency, product_data:{name}, unit_amount}, quantity}
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: items,
      mode: 'payment',
      success_url: req.body.success_url || 'http://localhost:5173/success',
      cancel_url: req.body.cancel_url || 'http://localhost:5173/cancel',
    });
    res.json({ id: session.id, url: session.url });
  } catch (e) {
    console.error('Stripe error', e);
    res.status(500).json({ error: e.message });
  }
});



// Stripe webhook endpoint (recommended to run behind HTTPS)
app.post('/api/webhook', express.raw({type: 'application/json'}), (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!STRIPE_KEY || !webhookSecret) {
    console.warn('Webhook called but STRIPE_KEY or STRIPE_WEBHOOK_SECRET not configured.');
    return res.status(400).send('Webhook not configured.');
  }
  let event;
  try {
    const stripe = Stripe(STRIPE_KEY);
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle the checkout.session.completed event
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    console.log('Payment succeeded for session:', session.id);
    // TODO: fulfill order, mark as paid in DB, send confirmation email, etc.
  }

  res.json({received: true});
});


// Admin endpoint: list orders (protected)
app.get('/api/orders', authMiddleware, (req, res) => {
  // only allow admin role to view orders
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  db.all('SELECT * FROM orders ORDER BY created_at DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Server started on', PORT));
