Place generated Prisma migrations here after running `npx prisma migrate dev` in the server directory.
