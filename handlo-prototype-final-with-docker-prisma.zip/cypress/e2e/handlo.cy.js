
describe('Handlo E2E demo', () => {
  it('loads home page and navigates to catalog', () => {
    cy.visit('/')
    cy.contains('Wszystko, czego potrzebujesz').should('exist')
    cy.contains('Przeglądaj oferty').click()
    cy.contains('Wszystkie oferty').should('exist')
  })

  it('opens product and adds to cart', () => {
    cy.visit('/')
    cy.get('[data-cy=product-card]').first().click()
    cy.contains('Dodaj do koszyka').click()
    cy.get('[data-cy=cart-button]').click()
    cy.contains('Twój koszyk').should('exist')
  })
})
